import React from 'react'

import Rotas from './routes'
import 'bootstrap/dist/css/bootstrap.min.css'

function App() {
  return (
    <>
     <Rotas />
    </>
  );
}

export default App;
