import { Menu } from "../../components/Menu"

export const QuemSomos = () => {
    return(
        <>
            <Menu paginaAtual={"QuemSomos"} />
        </>
    )
}